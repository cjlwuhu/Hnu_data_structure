#include "node.h"
#include<bits/stdc++.h>
using namespace std;

node::node(int val,int exp)
{
	this->val = val;
	this->exp = exp;
	this->next = nullptr;
}


void add(List head , int val, int exp){
	List now = head;
	while(now->next != nullptr){
//		cout<<"k"; 
		if(now->exp == exp) {
			now->val += val;
//			cout<<"b";
			return;
		}
		
		if(now->exp > exp && now->next->exp < exp){
			List temp = new node(val,exp);
			 temp->next = now->next;
			now->next = temp;
			
//			cout<<"c";
			return;
		}
		now = now->next; 
	}
//	cout<<"a";
	
	if(now ->exp == exp){
		 now->val += val;
//		 cout<<"d";
	}
	else{
		List temp = new node(val,exp);
			temp->next = now->next;
			now->next = temp;
//			cout<<"e"<<head->next->val<<" "<<head->next->exp<<endl;
	}
	
	return;
} 

void printList(List head){
	head = head->next;
	
	while(head != nullptr){
		cout<<head->val<<" "<<head->exp<<endl;
		head=head->next; 
	}
}
