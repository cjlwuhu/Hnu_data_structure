#include<bits/stdc++.h>
#include "node.h"
using namespace std;

int n , v , e; 

int main(){
	List head = new node(-1,100000);
	
	
	for(int i=0;i<=1;i++) {
		cin>>n;
		for(int j=0;j<n;j++){
			cin>>v>>e;
			add(head,v,e);
		}
	}
	printList(head);
	return 0;
}
