#ifndef NODE_H
#define NODE_H

class node;
typedef node* List;
class node
{
	public:
		List next;
		int val;
		int exp;
		
		node(int val , int exp ); 
		friend void add(List, int, int);
		friend void printList(List head);
};

#endif
