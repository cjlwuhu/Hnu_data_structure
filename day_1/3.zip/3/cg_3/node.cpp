#include "node.h"
#include<bits/stdc++.h>
using namespace std;

node::node(double x,double y,double angle , int idx)
{
	this->x = x;
	this->y = y;
	this->angle = angle;
	this->right = nullptr;
	this->left = nullptr;
	this->idx = idx;
}

void node::POP(){
	List l=this->left,r=this->right;
	
	l->right = r;
	r->left = l;
	
	delete(this);
}

