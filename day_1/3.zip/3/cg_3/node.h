#ifndef NODE_H
#define NODE_H

class node;
typedef node* List;
class node
{
	public:
		List right;
		List left;
		double x;
		double y;
		double angle;
		int idx;
 		
		node(double, double , double  , int); 
		void POP();
};

#endif
