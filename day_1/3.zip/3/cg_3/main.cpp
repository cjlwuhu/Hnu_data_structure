#include<bits/stdc++.h>
#include "node.h"
using namespace std;

int n , v , e ;
double min_y = 10000; 
struct point{
	double x=0,y=0,ang=0 , dis=0;
}p[100000],p0;

bool cmp(point a , point b){
	if(a.ang != b.ang)
		return a.ang<b.ang;
	else if(a.dis != b.dis)
		return a.dis<b.dis;
	else if(a.x != b.x)
		return a.x < b.x;
	else return a.y < b.y; 
}

bool cmp_xy(point a, point b){
    if(a.x != b.x) return a.x < b.x;
    return a.y < b.y;
}

double cal_k(int id1,int id2){
	double x0 = p[id1].x,y0=p[id1].y,x1=p[id2].x ,y1=p[id2].y;
	double res = (y0-y1)/(x0-x1);
	return res;
}

double cal_k(List id1,List id2){
    double x0 = id1->x, y0 = id1->y;
    double x1 = id2->x, y1 = id2->y;
    return (y0 - y1) / (x0 - x1);
}

double cal_b(int id1,int id2){
	double x0 = p[id1].x,y0=p[id1].y,x1=p[id2].x , y1=p[id2].y;
	double res=(y1*x0-y0*x1)/(x0-x1);
	return res;
}

double cross(point a, point b, point c){
    return (b.x-a.x)*(c.y-a.y) - (b.y-a.y)*(c.x-a.x);
}

double minn_x=100000,maxx_x=-100000;
int minn_id , maxx_id;
bool is_oneline(){
    minn_id = 0;
    maxx_id = 0;
    for(int i=1;i<n;i++){
        if(p[i].x < p[minn_id].x || (p[i].x == p[minn_id].x && p[i].y < p[minn_id].y))
            minn_id = i;
        if(p[i].x > p[maxx_id].x || (p[i].x == p[maxx_id].x && p[i].y > p[maxx_id].y))
            maxx_id = i;
    }

    for(int i=2;i<n;i++){
        if(cross(p[0], p[1], p[i]) != 0) return false;
    }
    return true;
}

double cross(List a, List b, List c){
    return (b->x-a->x)*(c->y-a->y) - (b->y-a->y)*(c->x-a->x);
}

const double pi = acos(-1);
void cal_angle(int id){
	double x = p[id].x,y=p[id].y;
	double x0=p0.x,y0=p0.y;
	
	p[id].dis = sqrt((x-x0)*(x-x0)+(y-y0)*(y-y0));
	double dx = p[id].x - p0.x;
	double dy = p[id].y - p0.y;
	double ang = atan2(dx, -dy);  
	if(ang < 0) ang += 2 * pi;
	p[id].ang = ang;
} 

List head;
List tail = new node(-1,100000 , 0 , -1);
List temp_h = new node(-1,100000 , 0 , -1);
void build_node(){
    List first = nullptr, prev = nullptr;
    head = nullptr;

    for(int i=0;i<n;i++){
        List temp = new node(p[i].x, p[i].y, p[i].ang, i);

        if(first == nullptr) first = temp;
        if(prev != nullptr){
            prev->right = temp;
            temp->left = prev;
        }
        prev = temp;

        if(temp->y == min_y){
            if(head == nullptr || temp->x > head->x) head = temp; // y��Сʱȡx���
        }
    }

    first->left = prev;
    prev->right = first;
}

int main(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>p[i].x>>p[i].y;
		if(p[i].y<min_y) {
			min_y = p[i].y;
		}
	}
	
	if(n<=2){
		sort(p,p+n,cmp_xy);
		for(int i=0;i<n;i++)
			cout<<p[i].x<<" "<<p[i].y<<endl;
		return 0;
	}
	
	if(is_oneline()){
		cout<<p[minn_id].x<<" "<<p[minn_id].y<<endl<<p[maxx_id].x<<" "<<p[maxx_id].y;
		return 0;
	}
	
	
	int a = 0, b = 1, c = -1;
	for(int i = 2; i < n; i++){
	    if(cross(p[a], p[b], p[i]) != 0){
	        c = i;
	        break;
	    }
	}
	p0.x = (p[a].x + p[b].x + p[c].x) / 3.0;
	p0.y = (p[a].y + p[b].y + p[c].y) / 3.0;
	
	
	for(int i=0;i<n;i++)
		cal_angle(i);
	
	sort(p,p+n,cmp);
	
	build_node();
	
	bool changed = true;
	while(changed){
	    changed = false;
	    List t = head;
	    List rt = t->right;
	
	    do{
	        List rrt = rt->right;
	        if(cross(t, rt, rrt) <= 0){
	            if(rt == head) head = rrt;
	            List del = rt;
	            rt = t;
	            t = rt->left;
	            del->POP();
	            changed = true;
	        }else{
	            t = rt;
	            rt = rrt;
	        }
	    }while(rt != head);
	}
	
	vector<point> anss;
	List t = head;
	do{
	    point tmp;
	    tmp.x = t->x;
	    tmp.y = t->y;
	    tmp.ang = 0;
	    tmp.dis = 0;
	    anss.push_back(tmp);
	    t = t->right;
	}while(t != head);

	sort(anss.begin() , anss.end() , cmp_xy);
	
	for(auto i : anss){
		cout<<i.x<<" "<<i.y<<endl;
	}
	return 0;
}
